## Argomenti

- Meccaniche platformer 2D a scorrimento laterale
- collisioni con callback
- generazione random del livello e delle entità di gioco
- nemici con semplice IA

